var janela = document.getElementById("janela");


function abrirJanela(){
	janela.src = "img/janelaaberta.jpg";
}

function fecharJanela(){
	janela.src = "img/janelafechada.jpg";
}

function quebrarJanela(){
	janela.src = "img/janelaquebrada.jpg";
}