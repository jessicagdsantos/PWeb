// var sql = require ('mssql/msnodesqlv8'); 
// module.exports = function(){ 
 
//  const config = { 
//  user: 'BD2013032', 
//  password: 'Jessica1', 
//  database: 'BD', //your database 
//  server: '192.168.1.6', 
//  driver: 'msnodesqlv8', 
//  } 
//  return sql.connect(config); 
// } 

var sql = require ('mssql/msnodesqlv8'); 
var connSQLServer = function(){ 
    console.log('Conexao com o banco de dados estabelecida!'); 
    const config = { 
    user: 'BD2013032', 
    password: 'Jessica1', 
    database: 'BD', //your database 
    server: '192.168.1.6', 
    driver: 'msnodesqlv8', 
    } 
    
    return sql.connect(config); 
   } 
   // exportando a função e quando chamar a página ele conecta 
   module.exports = function(){ 
    console.log('O autoload carregou o módulo de conexão com o bd'); 
    return connSQLServer; 
   } 