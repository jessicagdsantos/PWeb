// // module.exports = function(app) { 
// //     app.get('/informacao/professores', function(req,res){ 
// //      res.render('informacao/professores'); 
// //     }); 
// //     } 

// module.exports = function(app){ 
//     app.get('/informacao/professores', function(req,res){ 
//     const sql = require ('mssql/msnodesqlv8'); 
//     const sqlConfig = { 
//     user: 'BD2013032', 
//     password: 'Jessica1', 
//     database: 'BD', 
//     server: '192.168.1.6',
//     } 
    
//     async function getProfessores() { 
//     try { 
//     const pool = await sql.connect(sqlConfig); 
    
//     const results = await pool.request().query('SELECT * from PROFESSORES') 
    
//     res.render('informacao/professores',{profs : results.recordset}); 
 
// } catch (err) { 
// console.log(err) 
// } 
// } 
// const professores = getProfessores(); 
// }); 
// } 

const sql = require ('mssql');
// para acessar o arquivo de config voltar 1 nivel 
//C:\PWEBNode\Exercícios\app\config 
//var dbConnection = require('../config/dbConnection'); 
module.exports = function(app){ 
 app.get('/informacao/professores', function(req,res){ 
 async function getProfessores() { 
 try { 
 const pool = await dbConnection(); // executando a funcao 
 const results = await pool.request().query('SELECT * from PROFESSORES'); 
 res.render('informacao/professores',{profs : results.recordset}); 
 } catch (err) { 
 console.log(err) 
 } 
 } 
 const professores = getProfessores(); 
 }); 
}; 