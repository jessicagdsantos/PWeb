// var app = require('./app/config/server'); // carregando o módulo do servidor 
// app.get('/', function(req,res){ 
//  res.render("home/index"); 
// }); 
// app.get('/formulario_adicionar_usuario', function(req,res){ 
//  res.render("admin/adicionar_usuario"); 
// }); 
// app.get('/informacao/historia', function(req,res){ 
//  res.render("informacao/historia"); 
// }); 
// app.get('/informacao/cursos', function(req,res){ 
//  res.render("informacao/cursos") 
// }); 
// app.get('/informacao/professores', function(req,res){ 
//  res.render("informacao/professores"); 
// }); 
// app.listen(3000, function(){ 
//  console.log("servidor iniciado"); 
// });

// var app = require('./app/config/server'); 
// var rotaHome = require('./app/routes/home'); 
// rotaHome(app); 
// var rotaAdicionarUsuario = require('./app/routes/adicionar_usuario'); 
// rotaAdicionarUsuario(app); 
// var rotaHistoria = require('./app/routes/historia'); // só está definindo 
// rotaHistoria(app); // está executando 
// var rotaCursos = require('./app/routes/cursos'); // só está definindo 
// rotaCursos(app); // está executando 
// var rotaProfessores = require('./app/routes/professores'); // só está definindo 
// rotaProfessores(app); // está executando 
// /* poderia executar assim também*/ 
// /* 
// var rotaAdicionarUsuario = require('./app/routes/adicionar_usuario')(app); 
// */ 
// app.listen(3000, function(){ 
//     console.log("servidor iniciado"); 
//    }); 

var app = require('./app/config/server'); 
/*var rotaHome = require('./app/routes/home'); 
//rotaHome(app); 
var rotaAdicionarUsuario = require('./app/routes/adicionar_usuario'); 
rotaAdicionarUsuario(app); 
var rotaHistoria = require('./app/routes/historia'); // só esta definindo 
rotaHistoria(app); // está executando 
var rotaCursos = require('./app/routes/cursos'); // só esta definindo 
rotaCursos(app); // está executando 
var rotaProfessores = require('./app/routes/professores'); // só esta definindo
rotaProfessores(app); // está executando 
*/ 
app.listen(3000, function(){ 
    console.log("servidor iniciado"); 
   }); 
   
   

